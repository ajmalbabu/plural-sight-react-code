import React, {
  AppRegistry,
} from 'react-native';

import PluralTodo from './PluralTodo';


AppRegistry.registerComponent('FullPluralTodo', () => PluralTodo);
